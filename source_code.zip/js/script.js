document.addEventListener('DOMContentLoaded', () => {
    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.querySelector('.nav-menu');
    const navLinks = document.querySelectorAll('.nav-link');
    const navbar = document.querySelector('.navbar');
    const contactForm = document.getElementById('contactForm');
    const formStatus = document.getElementById('form-status');
    const languageToggle = document.getElementById('language-toggle');
    const languageDropdown = document.getElementById('language-dropdown');
    const languageOptions = document.querySelectorAll('.language-option');
    const currentLanguageText = document.getElementById('current-language');
    
    // Animation on scroll
    const animateOnScroll = () => {
        const elements = document.querySelectorAll('.fade-in, .fade-in-up, .fade-in-left, .fade-in-right');
        
        elements.forEach(element => {
            const elementPosition = element.getBoundingClientRect().top;
            const windowHeight = window.innerHeight;
            
            if (elementPosition < windowHeight - 100) {
                element.style.visibility = 'visible';
                element.style.animationPlayState = 'running';
            }
        });
    };
    
    // Initial check for elements in view
    animateOnScroll();
    
    // Add scroll event listener
    window.addEventListener('scroll', animateOnScroll);

    // Toggle mobile menu
    hamburger.addEventListener('click', () => {
        hamburger.classList.toggle('active');
        navMenu.classList.toggle('active');
    });

    // Close mobile menu when a link is clicked
    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            if (navMenu.classList.contains('active')) {
                hamburger.classList.remove('active');
                navMenu.classList.remove('active');
            }
            // Active link highlighting
            navLinks.forEach(item => item.classList.remove('active'));
            link.classList.add('active');
        });
    });

    // Smooth scrolling for anchor links & offset for fixed navbar
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            const targetElement = document.querySelector(targetId);

            if (targetElement) {
                let offset = navbar.offsetHeight + 20; // Extra spacing
                
                const elementPosition = targetElement.getBoundingClientRect().top;
                const offsetPosition = elementPosition + window.pageYOffset - offset;
                
                window.scrollTo({
                    top: offsetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Sticky navbar shrink on scroll
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }

        // Update active link on scroll
        updateActiveLink();
    });

    function updateActiveLink() {
        let currentSection = '';
        const sections = document.querySelectorAll('section');
        
        sections.forEach(section => {
            const sectionTop = section.offsetTop - navbar.offsetHeight - 80;
            if (pageYOffset >= sectionTop) {
                currentSection = section.getAttribute('id');
            }
        });

        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href').substring(1) === currentSection) {
                link.classList.add('active');
            }
        });
        
        // Ensure "Home" is active when at the top
        if (window.scrollY < 100) {
            navLinks.forEach(link => link.classList.remove('active'));
            document.querySelector('.nav-link[href="#hero"]').classList.add('active');
        }
    }

    // Contact Form Submission
    if (contactForm) {
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();
            formStatus.textContent = '';

            const name = document.getElementById('name').value.trim();
            const email = document.getElementById('email').value.trim();
            const service = document.getElementById('service').value;
            const message = document.getElementById('message').value.trim();

            // Validation
            if (!name || !email || !service || !message) {
                const errorMsg = window.translatedErrorMessages ? 
                    window.translatedErrorMessages['Please fill in all required fields.'] : 
                    'Please fill in all required fields.';
                showFormStatus(errorMsg, 'error');
                return;
            }
            
            if (!validateEmail(email)) {
                const errorMsg = window.translatedErrorMessages ? 
                    window.translatedErrorMessages['Please enter a valid email address.'] : 
                    'Please enter a valid email address.';
                showFormStatus(errorMsg, 'error');
                return;
            }

            // Show sending message
            const sendingMsg = window.translatedErrorMessages ? 
                window.translatedErrorMessages['Sending your message...'] : 
                'Sending your message...';
            showFormStatus(sendingMsg, 'loading');

            // Simulate form submission (replace with actual form handling)
            setTimeout(() => {
                const successMsg = window.translatedErrorMessages ? 
                    window.translatedErrorMessages['Message sent successfully! We will get back to you soon.'] : 
                    'Message sent successfully! We will get back to you soon.';
                showFormStatus(successMsg, 'success');
                contactForm.reset();
            }, 2000);
        });
    }

    function showFormStatus(message, type) {
        formStatus.textContent = message;
        formStatus.className = `form-status ${type}`;
        
        if (type === 'success') {
            formStatus.style.color = '#27ae60';
        } else if (type === 'error') {
            formStatus.style.color = '#e74c3c';
        } else {
            formStatus.style.color = '#3498db';
        }
    }

    function validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(String(email).toLowerCase());
    }
    
    // Set initial active link
    updateActiveLink();

    // Enhanced scroll effects
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);

    // Observe service cards for animation
    document.querySelectorAll('.service-card').forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(30px)';
        card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(card);
    });

    // Form validation enhancements
    const formInputs = document.querySelectorAll('#contactForm input, #contactForm select, #contactForm textarea');
    
    formInputs.forEach(input => {
        input.addEventListener('blur', () => {
            if (input.hasAttribute('required') && !input.value.trim()) {
                input.style.borderColor = '#e74c3c';
            } else {
                input.style.borderColor = '#ddd';
            }
        });

        input.addEventListener('focus', () => {
            input.style.borderColor = '#04375a';
        });
    });

    // Language switcher functionality
    if (languageToggle) {
        languageToggle.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            languageDropdown.classList.toggle('show');
            console.log('Language dropdown toggled');
        });
    }

    // Close language dropdown when clicking outside
    document.addEventListener('click', (e) => {
        if (languageDropdown && !languageToggle.contains(e.target) && !languageDropdown.contains(e.target)) {
            languageDropdown.classList.remove('show');
        }
    });

    // Handle language selection
    if (languageOptions && languageOptions.length > 0) {
        languageOptions.forEach(option => {
            // Remove existing event listeners if any
            option.removeEventListener('click', handleLanguageClick);
            
            // Add new event listener
            option.addEventListener('click', handleLanguageClick);
        });
    }
    
    function handleLanguageClick(e) {
        e.preventDefault();
        e.stopPropagation();
        
        const option = e.currentTarget;
        const lang = option.getAttribute('data-lang');
        
        // Update active class
        if (languageOptions) {
            languageOptions.forEach(el => el.classList.remove('active'));
            option.classList.add('active');
        }
        
        // Update button text
        if (currentLanguageText) {
            currentLanguageText.textContent = option.textContent;
        }
        
        // Change language
        const success = changeLanguage(lang);
        
        // Close dropdown
        if (languageDropdown) {
            languageDropdown.classList.remove('show');
        }
        
        // Log to confirm click event was triggered
        console.log('Language changed to:', lang, 'Success:', success);
    }

    // Save original text content for reverting back to English
    let originalTexts = {};

    // Initialize the original text storage
    function saveOriginalTexts() {
        const textElements = document.querySelectorAll('h1, h2, h3, h4, p, a, button, label, option, span');
        textElements.forEach(element => {
            // Skip elements that don't need translation (like social media icons)
            if (element.children.length > 0 && element.children[0].tagName === 'I' && element.textContent.trim() === '') {
                return;
            }
            
            const text = element.textContent.trim();
            if (text) {
                // Use a combination of element tag and text as key to avoid collisions
                const key = `${element.tagName.toLowerCase()}-${text}`;
                originalTexts[key] = text;
            }
        });
        
        // Save original placeholders
        const formElements = document.querySelectorAll('input, textarea');
        formElements.forEach(element => {
            if (element.placeholder) {
                originalTexts[`placeholder-${element.id}`] = element.placeholder;
            }
        });
        
        console.log('Original texts saved');
    }
    
    // Call once on page load
    saveOriginalTexts();

    function changeLanguage(lang) {
        // Dictionary of translations
        const translations = {
            'en': {
                'Home': 'Home',
                'Services': 'Services',
                'About': 'About',
                'Contact': 'Contact',
                'English': 'English',
                'Creole': 'Creole',
                'Honesty Multi Services': 'Honesty Multi Services',
                'Your trusted partner for immigration, tax filing, translation, and career services.': 'Your trusted partner for immigration, tax filing, translation, and career services.',
                'Explore Our Services': 'Explore Our Services',
                'Our Services': 'Our Services',
                'We offer comprehensive professional services to help you navigate complex processes with ease and confidence.': 'We offer comprehensive professional services to help you navigate complex processes with ease and confidence.',
                'Immigration Services': 'Immigration Services',
                'Expert guidance through the complexities of immigration procedures to help you achieve your goals.': 'Expert guidance through the complexities of immigration procedures to help you achieve your goals.',
                'Work Permit': 'Work Permit',
                'TPS (Temporary Protected Status)': 'TPS (Temporary Protected Status)',
                'Status Adjustment': 'Status Adjustment',
                'Asylum Applications': 'Asylum Applications',
                'Get Help': 'Get Help',
                'Non-Business Tax Filing': 'Non-Business Tax Filing',
                'Accurate and timely tax preparation services for individuals, ensuring maximum returns and compliance.': 'Accurate and timely tax preparation services for individuals, ensuring maximum returns and compliance.',
                'Individual Tax Returns': 'Individual Tax Returns',
                'Tax Planning': 'Tax Planning',
                'Tax Consultation': 'Tax Consultation',
                'Previous Year Filing': 'Previous Year Filing',
                'File Taxes': 'File Taxes',
                'Document Translation & Notarization': 'Document Translation & Notarization',
                'Professional translation and official notarization for all your important documents.': 'Professional translation and official notarization for all your important documents.',
                'Legal Documents': 'Legal Documents',
                'Immigration Forms': 'Immigration Forms',
                'Certificates & Diplomas': 'Certificates & Diplomas',
                'Official Notary Services': 'Official Notary Services',
                'Request Service': 'Request Service',
                'Resume Building': 'Resume Building',
                'Professional resume creation services to showcase your skills and experience for career advancement.': 'Professional resume creation services to showcase your skills and experience for career advancement.',
                'Resume Creation': 'Resume Creation',
                'Cover Letter Writing': 'Cover Letter Writing',
                'Career Counseling': 'Career Counseling',
                'Interview Preparation': 'Interview Preparation',
                'Build Resume': 'Build Resume',
                'About Us': 'About Us',
                'Contact Us Today': 'Contact Us Today',
                'Contact Us': 'Contact Us',
                'Ready to get started or have questions? Reach out to our team for professional assistance.': 'Ready to get started or have questions? Reach out to our team for professional assistance.',
                'Full Name': 'Full Name',
                'Email Address': 'Email Address',
                'Service Interested In': 'Service Interested In',
                '--Select a Service--': '--Select a Service--',
                'Message': 'Message',
                'Send Message': 'Send Message',
                'Our Office': 'Our Office',
                'Business Hours': 'Business Hours',
                'Monday - Friday: 9:00 AM - 5:00 PM': 'Monday - Friday: 9:00 AM - 5:00 PM',
                'Saturday: 10:00 AM - 2:00 PM (By Appointment)': 'Saturday: 10:00 AM - 2:00 PM (By Appointment)',
                'Sunday: Closed': 'Sunday: Closed',
                'Your name': 'Your name',
                'Your email': 'Your email',
                'How can we help you?': 'How can we help you?',
                '© 2025 Honesty Multi Services. All Rights Reserved.': '© 2025 Honesty Multi Services. All Rights Reserved.',
                'At Honesty Multi Services, we are a dedicated team of professionals committed to providing high-quality, reliable services to meet your diverse needs. With years of experience in immigration, tax preparation, document services, and career development, we pride ourselves on our client-focused approach and our ability to deliver results.': 'At Honesty Multi Services, we are a dedicated team of professionals committed to providing high-quality, reliable services to meet your diverse needs. With years of experience in immigration, tax preparation, document services, and career development, we pride ourselves on our client-focused approach and our ability to deliver results.',
                'Our mission is to simplify complex processes and empower our clients to achieve their personal and professional goals. Based in Springfield, Ohio, we believe in integrity, transparency, and excellence in everything we do - just as our name suggests.': 'Our mission is to simplify complex processes and empower our clients to achieve their personal and professional goals. Based in Springfield, Ohio, we believe in integrity, transparency, and excellence in everything we do - just as our name suggests.'
            },
            'ht': {
                'Home': 'Akèy',
                'Services': 'Sèvis',
                'About': 'Apropo',
                'Contact': 'Kontak',
                'English': 'Anglè',
                'Creole': 'Kreyòl',
                'Honesty Multi Services': 'Honesty Multi Services',
                'Your trusted partner for immigration, tax filing, translation, and career services.': 'Patnè ou fè konfyans pou imigrasyon, preparasyon taks, tradiksyon, ak sèvis karyè.',
                'Explore Our Services': 'Dekouvri Sèvis Nou',
                'Our Services': 'Sèvis Nou Yo',
                'We offer comprehensive professional services to help you navigate complex processes with ease and confidence.': 'Nou ofri sèvis pwofesyonèl konplè pou ede w navige pwosesis konplèks avèk fasilite ak konfyans.',
                'Immigration Services': 'Sèvis Imigrasyon',
                'Expert guidance through the complexities of immigration procedures to help you achieve your goals.': 'Gid ekspè nan konpleksite pwosedi imigrasyon pou ede w atenn objektif ou yo.',
                'Work Permit': 'Pèmi Travay',
                'TPS (Temporary Protected Status)': 'TPS (Stati Pwoteksyon Tanporè)',
                'Status Adjustment': 'Ajisteman Stati',
                'Asylum Applications': 'Aplikasyon Azil',
                'Get Help': 'Jwenn Èd',
                'Non-Business Tax Filing': 'Preparasyon Taks Pèsonèl',
                'Accurate and timely tax preparation services for individuals, ensuring maximum returns and compliance.': 'Sèvis preparasyon taks egzat ak alè pou moun, pou asire maksimòm retou ak konfòmite.',
                'Individual Tax Returns': 'Deklarasyon Taks Endividyèl',
                'Tax Planning': 'Planifikasyon Taks',
                'Tax Consultation': 'Konsiltasyon Taks',
                'Previous Year Filing': 'Deklarasyon Ane Pase',
                'File Taxes': 'Deklare Taks',
                'Document Translation & Notarization': 'Tradiksyon & Notarizasyon Dokiman',
                'Professional translation and official notarization for all your important documents.': 'Tradiksyon pwofesyonèl ak notarizasyon ofisyèl pou tout dokiman enpòtan ou yo.',
                'Legal Documents': 'Dokiman Legal',
                'Immigration Forms': 'Fòm Imigrasyon',
                'Certificates & Diplomas': 'Sètifika & Diplòm',
                'Official Notary Services': 'Sèvis Notarye Ofisyèl',
                'Request Service': 'Mande Sèvis',
                'Resume Building': 'Kreyasyon CV',
                'Professional resume creation services to showcase your skills and experience for career advancement.': 'Sèvis kreyasyon CV pwofesyonèl pou montre konpetans ak eksperyans ou pou avansman karyè.',
                'Resume Creation': 'Kreyasyon CV',
                'Cover Letter Writing': 'Redaksyon Lèt Motivasyon',
                'Career Counseling': 'Konsèy Karyè',
                'Interview Preparation': 'Preparasyon Entèvyou',
                'Build Resume': 'Kreye CV',
                'About Us': 'Apropo Nou',
                'Contact Us Today': 'Kontakte Nou Jodi a',
                'Contact Us': 'Kontakte Nou',
                'Ready to get started or have questions? Reach out to our team for professional assistance.': 'Ou pare pou kòmanse oswa ou gen kesyon? Kontakte ekip nou an pou asistans pwofesyonèl.',
                'Full Name': 'Non Konplè',
                'Email Address': 'Adrès Imèl',
                'Service Interested In': 'Sèvis Ki Enterese Ou',
                '--Select a Service--': '--Chwazi yon Sèvis--',
                'Message': 'Mesaj',
                'Send Message': 'Voye Mesaj',
                'Our Office': 'Biwo Nou',
                'Business Hours': 'Orè Biznis',
                'Monday - Friday: 9:00 AM - 5:00 PM': 'Lendi - Vandredi: 9:00 AM - 5:00 PM',
                'Saturday: Closed': 'Samdi: Fèmen',
                'Sunday: 10:00 AM - 2:00 PM (By Appointment Only)': 'Dimanch: 10:00 AM - 2:00 PM (Sou Randevou Sèlman)',
                'Your name': 'Non ou',
                'Your email': 'Imèl ou',
                'How can we help you?': 'Kijan nou ka ede ou?',
                '© 2025 Honesty Multi Services. All Rights Reserved.': '© 2025 Honesty Multi Services. Tout Dwa Rezève.',
                'At Honesty Multi Services, we are a dedicated team of professionals committed to providing high-quality, reliable services to meet your diverse needs. With years of experience in immigration, tax preparation, document services, and career development, we pride ourselves on our client-focused approach and our ability to deliver results.': 'Nan Honesty Multi Services, nou se yon ekip pwofesyonèl ki angaje pou bay sèvis kalite siperyè, fyab pou satisfè bezwen divès ou yo. Avèk anpil ane eksperyans nan imigrasyon, preparasyon taks, sèvis dokiman, ak devlopman karyè, nou fyè de apwòch nou ki santre sou kliyan ak kapasite nou pou nou bay rezilta.',
                'Our mission is to simplify complex processes and empower our clients to achieve their personal and professional goals. Based in Springfield, Ohio, we believe in integrity, transparency, and excellence in everything we do - just as our name suggests.': 'Misyon nou se senpliye pwosesis konplèks yo epi bay kliyan nou yo pouvwa pou yo reyalize objektif pèsonèl ak pwofesyonèl yo. Baze nan Springfield, Ohio, nou kwè nan entegrite, transparans, ak ekselans nan tout sa nou fè - jis jan non nou sijere.'
            }
        };

        console.log(`Changing language to ${lang}`);
        
        if (lang === 'en') {
            // If switching to English, restore original texts
            restoreOriginalTexts();
        } else {
            // For other languages, apply translations
            applyTranslations(lang, translations[lang]);
        }
        
        // Update active class on language options
        document.querySelectorAll('.language-option').forEach(el => {
            el.classList.remove('active');
            if (el.getAttribute('data-lang') === lang) {
                el.classList.add('active');
            }
        });
    }
    
    function restoreOriginalTexts() {
        console.log('Restoring original English texts');
        
        // Update current language text
        if (currentLanguageText) {
            currentLanguageText.textContent = 'English';
        }
        
        // Restore text content
        const textElements = document.querySelectorAll('h1, h2, h3, h4, p, a, button, label, option, span');
        textElements.forEach(element => {
            // Skip elements that don't need translation (like social media icons)
            if (element.children.length > 0 && element.children[0].tagName === 'I' && element.textContent.trim() === '') {
                return;
            }
            
            const text = element.textContent.trim();
            const key = `${element.tagName.toLowerCase()}-${text}`;
            
            if (originalTexts[key]) {
                element.textContent = originalTexts[key];
            }
        });
        
        // Restore placeholders
        const formElements = document.querySelectorAll('input, textarea');
        formElements.forEach(element => {
            if (element.placeholder && originalTexts[`placeholder-${element.id}`]) {
                element.placeholder = originalTexts[`placeholder-${element.id}`];
            }
        });
    }
    
    function applyTranslations(lang, translationDict) {
        // Get all text elements to translate
        const textElements = document.querySelectorAll('h1, h2, h3, h4, p, a, button, label, option, span, input, textarea');
        
        textElements.forEach(element => {
            // Handle placeholder text for form elements
            if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
                if (element.placeholder && translationDict[element.placeholder]) {
                    element.placeholder = translationDict[element.placeholder];
                }
                return;
            }
            
            const originalText = element.textContent.trim();
            
            // Skip elements that don't need translation (like social media icons)
            if (element.children.length > 0 && element.children[0].tagName === 'I' && element.textContent.trim() === '') {
                return;
            }
            
            // Find translation
            if (translationDict[originalText]) {
                element.textContent = translationDict[originalText];
            }
        });

        // Translate form status messages
        const errorMessages = {
            'en': {
                'Please fill in all required fields.': 'Please fill in all required fields.',
                'Please enter a valid email address.': 'Please enter a valid email address.',
                'Sending your message...': 'Sending your message...',
                'Message sent successfully! We will get back to you soon.': 'Message sent successfully! We will get back to you soon.'
            },
            'ht': {
                'Please fill in all required fields.': 'Tanpri ranpli tout chan obligatwa yo.',
                'Please enter a valid email address.': 'Tanpri antre yon adrès imèl ki valid.',
                'Sending your message...': 'Ap voye mesaj ou...',
                'Message sent successfully! We will get back to you soon.': 'Mesaj la voye avèk siksè! Nou pral kontakte ou byento.'
            }
        };
        
        // Store translated error messages for later use
        window.translatedErrorMessages = errorMessages[lang];

        // Change document language
        document.documentElement.lang = lang;
        
        console.log('Language change completed');
        return true;
    }
});